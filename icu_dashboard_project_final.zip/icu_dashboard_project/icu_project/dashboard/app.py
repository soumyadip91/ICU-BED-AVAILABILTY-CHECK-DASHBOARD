import sqlite3
import os
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from dash import Dash, dcc, html, dash_table, Input, Output
import dash_bootstrap_components as dbc  # optional, fallback CSS provided

DB_PATH = "data/icu_processed.db"

# ── Color palette ──────────────────────────────────────────────────────────
COLORS = {
    "primary"  : "#1a3c6e",
    "secondary": "#2e6da4",
    "accent"   : "#4db8ff",
    "danger"   : "#e53935",
    "warning"  : "#ff9800",
    "success"  : "#43a047",
    "bg"       : "#f0f4f8",
    "card"     : "#ffffff",
    "text"     : "#1a1a2e",
}

# ── Data loading helpers ───────────────────────────────────────────────────
def get_conn():
    return sqlite3.connect(DB_PATH)


def load_kpis():
    conn = get_conn()
    df = pd.read_sql("""
        SELECT
            SUM(total_icu_beds)           AS total_beds,
            SUM(occupied_beds)            AS occupied,
            SUM(available_beds)           AS available,
            ROUND(AVG(occupancy_rate),1)  AS avg_occ,
            COUNT(DISTINCT hospital_name) AS hospitals
        FROM icu_records
        WHERE record_date = (SELECT MAX(record_date) FROM icu_records)
    """, conn)
    conn.close()
    return df.iloc[0]


def load_regional():
    conn = get_conn()
    df = pd.read_sql("""
        SELECT region,
            SUM(total_icu_beds)           AS total_beds,
            SUM(available_beds)           AS available,
            ROUND(AVG(occupancy_rate),1)  AS avg_occupancy
        FROM icu_records
        WHERE record_date = (SELECT MAX(record_date) FROM icu_records)
        GROUP BY region ORDER BY avg_occupancy DESC
    """, conn)
    conn.close()
    return df


def load_trend():
    conn = get_conn()
    df = pd.read_sql("""
        SELECT SUBSTR(record_date,1,7) AS month,
               ROUND(AVG(occupancy_rate),2) AS avg_occupancy
        FROM icu_records
        GROUP BY month ORDER BY month
    """, conn)
    conn.close()
    return df


def load_hospital_table(region="All"):
    conn = get_conn()
    where = "" if region == "All" else f"AND r.region = '{region}'"
    df = pd.read_sql(f"""
        SELECT r.hospital_name AS Hospital,
               r.city          AS City,
               r.region        AS Region,
               r.total_icu_beds    AS "Total Beds",
               r.available_beds    AS "Available",
               r.occupancy_rate    AS "Occupancy %",
               ROUND(100-r.occupancy_rate,1) AS "Availability %",
               CASE
                 WHEN (100-r.occupancy_rate)<10 THEN 'CRITICAL'
                 WHEN (100-r.occupancy_rate)<20 THEN 'HIGH'
                 WHEN (100-r.occupancy_rate)<35 THEN 'WARNING'
                 ELSE 'NORMAL'
               END AS Status,
               r.record_date   AS "Date"
        FROM icu_records r
        INNER JOIN (
            SELECT hospital_name, MAX(record_date) AS max_date
            FROM icu_records GROUP BY hospital_name
        ) l ON r.hospital_name=l.hospital_name AND r.record_date=l.max_date
        WHERE 1=1 {where}
        ORDER BY r.occupancy_rate DESC
    """, conn)
    conn.close()
    return df


def load_alerts():
    conn = get_conn()
    df = pd.read_sql("""
        SELECT hospital_name AS Hospital, city AS City, region AS Region,
               available_beds AS "Available Beds", total_icu_beds AS "Total Beds",
               ROUND(100-occupancy_rate,1) AS "Availability %"
        FROM icu_records
        WHERE (100-occupancy_rate)<20
          AND record_date=(SELECT MAX(record_date) FROM icu_records)
        ORDER BY occupancy_rate DESC
    """, conn)
    conn.close()
    return df


def load_ward_breakdown():
    conn = get_conn()
    df = pd.read_sql("""
        SELECT ward_type,
               SUM(total_icu_beds)  AS total,
               SUM(available_beds)  AS available
        FROM icu_records
        WHERE record_date=(SELECT MAX(record_date) FROM icu_records)
        GROUP BY ward_type
    """, conn)
    conn.close()
    return df


def get_regions():
    conn = get_conn()
    regions = pd.read_sql("SELECT DISTINCT region FROM icu_records ORDER BY region", conn)
    conn.close()
    return ["All"] + regions["region"].tolist()


# ── Chart builders ─────────────────────────────────────────────────────────
def kpi_card(label, value, color=COLORS["primary"], suffix=""):
    return html.Div([
        html.P(label, style={"color": "#666", "fontSize": "13px", "marginBottom": "4px"}),
        html.H3(f"{value}{suffix}", style={"color": color, "margin": "0", "fontSize": "26px"}),
    ], style={
        "background": COLORS["card"], "borderRadius": "12px",
        "padding": "18px 22px", "boxShadow": "0 2px 8px rgba(0,0,0,0.08)",
        "borderLeft": f"5px solid {color}", "flex": "1", "minWidth": "160px",
    })


def build_regional_chart(df):
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=df["region"], y=df["avg_occupancy"],
        name="Avg Occupancy %",
        marker_color=[
            COLORS["danger"] if v > 75 else COLORS["warning"] if v > 60 else COLORS["success"]
            for v in df["avg_occupancy"]
        ],
        text=[f"{v}%" for v in df["avg_occupancy"]],
        textposition="outside",
    ))
    fig.update_layout(
        title="Region-wise Average ICU Occupancy (%)",
        xaxis_title="Region", yaxis_title="Occupancy %",
        yaxis=dict(range=[0, 100]),
        plot_bgcolor="white", paper_bgcolor="white",
        font=dict(family="Arial", size=13),
        margin=dict(t=50, b=40, l=40, r=20),
    )
    return fig


def build_trend_chart(df):
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df["month"], y=df["avg_occupancy"],
        mode="lines+markers",
        line=dict(color=COLORS["secondary"], width=2.5),
        marker=dict(size=6, color=COLORS["primary"]),
        fill="tozeroy",
        fillcolor="rgba(46,109,164,0.12)",
        name="Avg Occupancy %",
    ))
    fig.add_hline(y=80, line_dash="dash", line_color=COLORS["danger"],
                  annotation_text="Critical (80%)", annotation_position="bottom right")
    fig.update_layout(
        title="Monthly National ICU Occupancy Trend",
        xaxis_title="Month", yaxis_title="Avg Occupancy %",
        yaxis=dict(range=[0, 105]),
        plot_bgcolor="white", paper_bgcolor="white",
        font=dict(family="Arial", size=13),
        margin=dict(t=50, b=40, l=40, r=20),
    )
    return fig


def build_ward_donut(df):
    fig = go.Figure(go.Pie(
        labels=df["ward_type"],
        values=df["total"],
        hole=0.45,
        textinfo="label+percent",
        marker=dict(colors=px.colors.qualitative.Set2),
    ))
    fig.update_layout(
        title="ICU Beds by Ward Type",
        showlegend=True,
        plot_bgcolor="white", paper_bgcolor="white",
        font=dict(family="Arial", size=13),
        margin=dict(t=50, b=30, l=20, r=20),
    )
    return fig


# ── App Layout ─────────────────────────────────────────────────────────────
app = Dash(__name__, suppress_callback_exceptions=True)
app.title = "ICU Bed Availability Dashboard"

STATUS_COLORS = {
    "CRITICAL": "#fde8e8",
    "HIGH":     "#fff3e0",
    "WARNING":  "#fffde7",
    "NORMAL":   "#e8f5e9",
}

app.layout = html.Div(style={"background": COLORS["bg"], "minHeight": "100vh",
                              "fontFamily": "Arial, sans-serif", "color": COLORS["text"]}, children=[

    # Header
    html.Div([
        html.Div([
            html.H1("🏥 ICU Bed Availability Dashboard",
                    style={"color": "white", "margin": "0", "fontSize": "24px"}),
            html.P("Real-time ICU capacity monitoring across hospitals",
                   style={"color": "#b3d4f5", "margin": "4px 0 0 0", "fontSize": "13px"}),
        ]),
        html.Div([
            html.P("Data Engineering Capstone Project",
                   style={"color": "#b3d4f5", "margin": "0", "fontSize": "12px",
                           "textAlign": "right"}),
        ]),
    ], style={
        "background": f"linear-gradient(135deg, {COLORS['primary']}, {COLORS['secondary']})",
        "padding": "20px 30px", "display": "flex",
        "justifyContent": "space-between", "alignItems": "center",
        "boxShadow": "0 3px 10px rgba(0,0,0,0.15)",
    }),

    html.Div(style={"padding": "20px 30px"}, children=[

        # KPI Cards row
        html.Div(id="kpi-row", style={"display": "flex", "gap": "14px",
                                        "flexWrap": "wrap", "marginBottom": "20px"}),

        # Alert Banner
        html.Div(id="alert-banner"),

        # Filter row
        html.Div([
            html.Label("Filter by Region:", style={"fontWeight": "bold", "marginRight": "10px"}),
            dcc.Dropdown(
                id="region-filter",
                options=[{"label": r, "value": r} for r in get_regions()],
                value="All",
                clearable=False,
                style={"width": "200px", "display": "inline-block"},
            ),
        ], style={"marginBottom": "20px", "display": "flex", "alignItems": "center"}),

        # Charts row 1: Regional + Trend
        html.Div([
            html.Div([dcc.Graph(id="regional-chart")],
                     style={"flex": "1", "background": "white", "borderRadius": "12px",
                             "boxShadow": "0 2px 8px rgba(0,0,0,0.08)", "padding": "10px",
                             "minWidth": "300px"}),
            html.Div([dcc.Graph(id="trend-chart")],
                     style={"flex": "1", "background": "white", "borderRadius": "12px",
                             "boxShadow": "0 2px 8px rgba(0,0,0,0.08)", "padding": "10px",
                             "minWidth": "300px"}),
        ], style={"display": "flex", "gap": "16px", "marginBottom": "20px", "flexWrap": "wrap"}),

        # Charts row 2: Ward donut + Alerts table
        html.Div([
            html.Div([dcc.Graph(id="ward-donut")],
                     style={"flex": "1", "background": "white", "borderRadius": "12px",
                             "boxShadow": "0 2px 8px rgba(0,0,0,0.08)", "padding": "10px",
                             "minWidth": "280px", "maxWidth": "380px"}),
            html.Div([
                html.H4("⚠️ Low Availability Alerts (< 20%)",
                        style={"color": COLORS["danger"], "margin": "0 0 12px 0"}),
                html.Div(id="alert-table"),
            ], style={"flex": "2", "background": "white", "borderRadius": "12px",
                       "boxShadow": "0 2px 8px rgba(0,0,0,0.08)", "padding": "16px",
                       "minWidth": "300px"}),
        ], style={"display": "flex", "gap": "16px", "marginBottom": "20px", "flexWrap": "wrap"}),

        # Full hospital data table
        html.Div([
            html.H4("📋 Hospital ICU Status Table",
                    style={"color": COLORS["primary"], "margin": "0 0 12px 0"}),
            html.Div(id="hospital-table"),
        ], style={"background": "white", "borderRadius": "12px",
                   "boxShadow": "0 2px 8px rgba(0,0,0,0.08)", "padding": "16px"}),

    ]),
])


# ── Callbacks ─────────────────────────────────────────────────────────────
@app.callback(
    Output("kpi-row", "children"),
    Input("region-filter", "value"),
)
def update_kpis(region):
    kpi = load_kpis()
    return [
        kpi_card("Total ICU Beds",      int(kpi["total_beds"]),  COLORS["primary"]),
        kpi_card("Occupied Beds",        int(kpi["occupied"]),    COLORS["danger"]),
        kpi_card("Available Beds",       int(kpi["available"]),   COLORS["success"]),
        kpi_card("Avg Occupancy",        kpi["avg_occ"],          COLORS["warning"], "%"),
        kpi_card("Hospitals Monitored",  int(kpi["hospitals"]),   COLORS["secondary"]),
    ]


@app.callback(
    Output("alert-banner", "children"),
    Input("region-filter", "value"),
)
def update_alert_banner(_):
    df = load_alerts()
    count = len(df)
    if count == 0:
        return html.Div("✅ All hospitals have adequate ICU bed availability.",
                        style={"background": "#e8f5e9", "color": "#2e7d32",
                               "padding": "10px 16px", "borderRadius": "8px",
                               "marginBottom": "16px", "fontWeight": "bold"})
    return html.Div(f"🚨 {count} hospital(s) have less than 20% ICU availability — IMMEDIATE ATTENTION REQUIRED",
                    style={"background": "#fde8e8", "color": COLORS["danger"],
                           "padding": "10px 16px", "borderRadius": "8px",
                           "marginBottom": "16px", "fontWeight": "bold",
                           "border": f"1px solid {COLORS['danger']}"})


@app.callback(
    Output("regional-chart", "figure"),
    Input("region-filter", "value"),
)
def update_regional(_):
    return build_regional_chart(load_regional())


@app.callback(
    Output("trend-chart", "figure"),
    Input("region-filter", "value"),
)
def update_trend(_):
    return build_trend_chart(load_trend())


@app.callback(
    Output("ward-donut", "figure"),
    Input("region-filter", "value"),
)
def update_ward(_):
    return build_ward_donut(load_ward_breakdown())


@app.callback(
    Output("alert-table", "children"),
    Input("region-filter", "value"),
)
def update_alert_table(_):
    df = load_alerts()
    if df.empty:
        return html.P("No alerts. All hospitals above 20% availability.",
                      style={"color": COLORS["success"]})
    return dash_table.DataTable(
        data=df.to_dict("records"),
        columns=[{"name": c, "id": c} for c in df.columns],
        style_cell={"fontFamily": "Arial", "fontSize": "12px",
                     "padding": "6px", "textAlign": "left"},
        style_header={"backgroundColor": COLORS["danger"], "color": "white",
                        "fontWeight": "bold"},
        style_data_conditional=[
            {"if": {"filter_query": '{Availability %} < 10'},
             "backgroundColor": "#fde8e8"},
        ],
        page_size=8,
        style_table={"overflowX": "auto"},
    )


@app.callback(
    Output("hospital-table", "children"),
    Input("region-filter", "value"),
)
def update_hospital_table(region):
    df = load_hospital_table(region)
    return dash_table.DataTable(
        data=df.to_dict("records"),
        columns=[{"name": c, "id": c} for c in df.columns],
        filter_action="native",
        sort_action="native",
        page_size=12,
        style_cell={"fontFamily": "Arial", "fontSize": "12px",
                     "padding": "6px 10px", "textAlign": "left"},
        style_header={
            "backgroundColor": COLORS["primary"], "color": "white",
            "fontWeight": "bold", "textAlign": "center",
        },
        style_data_conditional=[
            {"if": {"filter_query": '{Status} = CRITICAL'},
             "backgroundColor": "#fde8e8", "color": COLORS["danger"]},
            {"if": {"filter_query": '{Status} = HIGH'},
             "backgroundColor": "#fff3e0"},
            {"if": {"filter_query": '{Status} = WARNING'},
             "backgroundColor": "#fffde7"},
            {"if": {"filter_query": '{Status} = NORMAL'},
             "backgroundColor": "#e8f5e9"},
        ],
        style_table={"overflowX": "auto"},
        export_format="csv",
    )


if __name__ == "__main__":
    print("[Dashboard] Starting ICU Bed Availability Dashboard...")
    print(f"[Dashboard] Database: {DB_PATH}")
    print("[Dashboard] Open browser at: http://localhost:8050")
    app.run(debug=True, host="0.0.0.0", port=8050)

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak, KeepTogether
)
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT

OUTPUT = "/home/claude/icu_project/docs/Project_Documentation_ICU_Dashboard.pdf"


def add_page_number(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 9)
    canvas.drawRightString(A4[0] - 1.5 * cm, 1.2 * cm, str(doc.page))
    canvas.restoreState()


def build():
    doc = SimpleDocTemplate(
        OUTPUT, pagesize=A4,
        rightMargin=2.5*cm, leftMargin=2.5*cm,
        topMargin=2*cm, bottomMargin=2*cm
    )

    styles = getSampleStyleSheet()
    H1 = ParagraphStyle("H1", fontName="Helvetica-Bold", fontSize=15,
                          spaceAfter=8, spaceBefore=14,
                          textColor=colors.HexColor("#1a3c6e"))
    H2 = ParagraphStyle("H2", fontName="Helvetica-Bold", fontSize=14,
                          spaceAfter=6, spaceBefore=10,
                          textColor=colors.HexColor("#2e6da4"))
    BODY = ParagraphStyle("Body", fontName="Helvetica", fontSize=12,
                           leading=20, alignment=TA_JUSTIFY, spaceAfter=6)
    CENTER = ParagraphStyle("Center", fontName="Helvetica", fontSize=12,
                             alignment=TA_CENTER)
    TITLE = ParagraphStyle("Title", fontName="Helvetica-Bold", fontSize=18,
                             alignment=TA_CENTER, textColor=colors.HexColor("#1a3c6e"),
                             spaceAfter=6)
    SUB_TITLE = ParagraphStyle("SubTitle", fontName="Helvetica", fontSize=14,
                                 alignment=TA_CENTER,
                                 textColor=colors.HexColor("#2e6da4"), spaceAfter=4)

    story = []

    # ── TITLE PAGE ────────────────────────────────────────────────────────────
    story.append(Spacer(1, 1.5*cm))
    story.append(Paragraph("ICU Bed Availability Dashboard", TITLE))
    story.append(Paragraph("Data Engineering Capstone Project", SUB_TITLE))
    story.append(Spacer(1, 0.4*cm))
    story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#1a3c6e")))
    story.append(Spacer(1, 0.8*cm))

    meta = [
        ["Subject",    "Data Engineering"],
        ["Batch",      "_______________"],
        ["Roll No.",   "_______________"],
        ["Name",       "_______________"],
        ["Deadline",   "April 21, 2026"],
        ["Tech Stack", "Python | SQL | Hadoop | Spark | Kafka | Airflow | AWS S3"],
    ]
    mt = Table(meta, colWidths=[4*cm, 11*cm])
    mt.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (1, 0), (1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 12),
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#dce8f5")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(mt)
    story.append(PageBreak())

    # ── PAGE 1: Problem Statement + Solution ─────────────────────────────────
    story.append(Paragraph("1. Problem Statement", H1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.2*cm))
    story.append(Paragraph(
        "In critical healthcare settings, Intensive Care Units (ICUs) represent a scarce and "
        "life-saving resource. During health emergencies — such as disease outbreaks, seasonal "
        "surges, or mass casualty events — hospitals face the challenge of managing ICU bed "
        "availability across multiple facilities, cities, and regions in real time.",
        BODY))
    story.append(Paragraph(
        "The core problem is the absence of a centralized, data-driven system that can ingest "
        "ICU occupancy data continuously, process it reliably at scale, and present actionable "
        "insights to healthcare administrators and policymakers. Without such a system, resource "
        "allocation decisions are delayed, patients may be transferred to already-full facilities, "
        "and critical shortages go undetected until it is too late.",
        BODY))
    story.append(Paragraph(
        "This project addresses this gap by building a complete end-to-end Data Engineering "
        "pipeline that collects, processes, stores, and visualizes ICU bed availability data "
        "from hospitals across multiple regions, enabling real-time monitoring and early "
        "alerting for dangerously low availability situations.",
        BODY))

    story.append(Paragraph("2. Solution and Features", H1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.2*cm))
    story.append(Paragraph(
        "The solution implements a Lambda Architecture-inspired pipeline consisting of five "
        "integrated layers: streaming ingestion via Apache Kafka, distributed raw storage on "
        "Hadoop HDFS and AWS S3, large-scale transformation using Apache Spark, structured "
        "query support through SQL (SQLite), automated orchestration via Apache Airflow, and "
        "a fully interactive analytical dashboard built with Python Dash and Plotly.",
        BODY))

    features = [
        ["Feature", "Description"],
        ["Kafka Streaming", "Python producer reads 7,300+ ICU records and streams them as JSON messages to the icu_beds Kafka topic."],
        ["HDFS Storage", "Kafka consumer writes raw messages to HDFS partitioned by date under /icu/raw/."],
        ["Spark ETL", "PySpark cleans nulls, recalculates occupancy rate, adds availability status flag, and writes Parquet to /icu/processed/."],
        ["AWS S3 Backup", "boto3 uploads processed files to S3 bucket 'icu-bed-dashboard-data' in ap-south-1 (Mumbai)."],
        ["SQL Views", "SQLite database with 4 analytical views: regional_summary, hospital_summary, alert_hospitals, monthly_trend."],
        ["Airflow DAG", "6-task DAG runs daily at 01:00, chaining generate → produce → consume → spark → SQL → S3."],
        ["Dashboard", "Dash app: KPI cards, region bar chart, monthly trend, ward donut, alert table, hospital data table with CSV export."],
    ]
    ft = Table(features, colWidths=[3.5*cm, 12.5*cm])
    ft.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3c6e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f0f6fc")]),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(ft)
    story.append(PageBreak())

    # ── PAGE 2: Tech Stack + Architecture ─────────────────────────────────────
    story.append(Paragraph("3. Technology Stack", H1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.2*cm))

    stack = [
        ["Technology", "Version", "Role in Project"],
        ["Python", "3.10+", "Data generation, Kafka scripts, S3 upload, SQL loading, dashboard"],
        ["Apache Kafka", "3.x", "Message broker for streaming ICU records from CSV to HDFS"],
        ["Apache Hadoop (HDFS)", "3.x", "Distributed storage of raw JSON and processed Parquet files"],
        ["Apache Spark (PySpark)", "3.x", "Distributed ETL: cleaning, transformation, occupancy computation"],
        ["Apache Airflow", "2.x", "DAG-based daily pipeline scheduling and task orchestration"],
        ["AWS S3", "—", "Cloud object storage for processed data backup (boto3)"],
        ["SQLite (SQL)", "3.x", "Relational database with analytical views for dashboard queries"],
        ["Pandas", "2.x", "DataFrame manipulation in Python scripts"],
        ["Dash + Plotly", "2.x", "Interactive web-based ICU dashboard on localhost:8050"],
    ]
    st = Table(stack, colWidths=[4*cm, 2.5*cm, 9.5*cm])
    st.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3c6e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f0f6fc")]),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(st)
    story.append(Spacer(1, 0.4*cm))

    story.append(Paragraph("4. Pipeline Architecture", H1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.2*cm))
    story.append(Paragraph(
        "The pipeline follows a five-layer architecture. The ingestion layer uses a Python "
        "Kafka producer to read the ICU CSV dataset and publish each record as a JSON event "
        "to the Kafka topic 'icu_beds'. A Kafka consumer listens on the topic and writes "
        "batched JSON files to HDFS under /icu/raw/, partitioned by date.",
        BODY))
    story.append(Paragraph(
        "The processing layer runs a PySpark job that reads raw HDFS data, removes null "
        "records, casts data types, recomputes occupancy rate (occupied / total × 100), "
        "adds an availability percentage column, and assigns an alert status flag "
        "(NORMAL / WARNING / CRITICAL). Output is written as Parquet to /icu/processed/.",
        BODY))
    story.append(Paragraph(
        "The storage layer simultaneously maintains HDFS for distributed access and AWS S3 "
        "for cloud durability. The serving layer loads processed data into SQLite via pandas "
        "and defines four SQL views used by the dashboard. The orchestration layer uses an "
        "Airflow DAG with six sequential tasks to automate and schedule the full pipeline "
        "on a daily basis.",
        BODY))

    flow_data = [
        ["Step", "Component", "Output"],
        ["1", "Python Dataset Generator", "icu_raw_dataset.csv (7,300 rows)"],
        ["2", "Kafka Producer", "JSON messages → topic: icu_beds"],
        ["3", "Kafka Consumer", "JSON files → HDFS /icu/raw/"],
        ["4", "PySpark ETL", "Parquet files → HDFS /icu/processed/"],
        ["5", "S3 Upload (boto3)", "Files → s3://icu-bed-dashboard-data/"],
        ["6", "SQL Loader", "SQLite: icu_processed.db + 4 views"],
        ["7", "Airflow DAG", "Orchestrates steps 1–6 daily"],
        ["8", "Dash Dashboard", "Web UI at http://localhost:8050"],
    ]
    flt = Table(flow_data, colWidths=[1.5*cm, 5*cm, 9.5*cm])
    flt.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3c6e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f0f6fc")]),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("ALIGN", (0, 0), (0, -1), "CENTER"),
    ]))
    story.append(flt)
    story.append(PageBreak())

    # ── PAGE 3: Unique Points + Future Improvements ───────────────────────────
    story.append(Paragraph("5. Unique Points and Highlights", H1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.2*cm))

    unique_points = [
        ("Real-World Healthcare Use Case",
         "The project addresses an actual healthcare problem — ICU capacity monitoring — "
         "making it directly applicable to hospital management systems and health emergency "
         "response platforms."),
        ("Full Pipeline Coverage of All Six Tools",
         "Every tool taught in the Data Engineering curriculum — Python, SQL, Hadoop, Spark, "
         "Kafka, Airflow, and AWS — is integrated into a single cohesive pipeline where each "
         "tool plays a distinct and non-redundant role."),
        ("Multi-layer Alert System",
         "The dashboard includes a three-tier alert system (CRITICAL < 10%, HIGH < 20%, "
         "WARNING < 35%) computed both in PySpark and in SQL, ensuring consistency across "
         "the processing and serving layers."),
        ("Seasonal Data Simulation",
         "The dataset generator simulates real-world seasonal ICU demand patterns, with "
         "higher occupancy during winter months (November to February), making the trend "
         "analysis and dashboard more meaningful and realistic."),
        ("Modular and Independently Runnable Components",
         "Each script in the pipeline can be run independently for testing without requiring "
         "the full infrastructure stack, making debugging and demonstration straightforward "
         "even in environments where Kafka or HDFS may not be running."),
    ]
    for title_up, desc_up in unique_points:
        story.append(Paragraph(f"• {title_up}", ParagraphStyle(
            "bullet_title", fontName="Helvetica-Bold", fontSize=12,
            spaceBefore=6, spaceAfter=2)))
        story.append(Paragraph(desc_up, BODY))

    story.append(Paragraph("6. Future Improvements", H1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.2*cm))

    future = [
        ("Real-time Data Integration",
         "Replace the simulated dataset with a live API feed from hospital management systems "
         "or government health portals (e.g., NHA's Aarogya Setu APIs) to enable true "
         "real-time ICU monitoring."),
        ("Predictive Analytics",
         "Integrate a machine learning model (e.g., ARIMA, Prophet, or LSTM) trained on "
         "historical occupancy trends to forecast ICU demand for the next 7–14 days, giving "
         "administrators advance warning before a shortage occurs."),
        ("Automated SMS/Email Alerts",
         "Add notification triggers in Airflow using Twilio (SMS) or SendGrid (email) to "
         "automatically alert designated health officials when any hospital crosses the "
         "critical occupancy threshold."),
        ("Cloud-native Deployment",
         "Migrate from local execution to a fully cloud-native setup using AWS EMR for Spark, "
         "Amazon MSK for managed Kafka, AWS MWAA for managed Airflow, and Amazon QuickSight "
         "or Grafana for the dashboard, enabling enterprise-scale deployment."),
        ("Multi-hospital Data Federation",
         "Extend the pipeline to ingest data from multiple independent hospital systems "
         "simultaneously using Kafka partitioning, enabling parallel processing and "
         "real-time aggregation across thousands of hospitals."),
    ]
    for title_f, desc_f in future:
        story.append(Paragraph(f"• {title_f}", ParagraphStyle(
            "future_title", fontName="Helvetica-Bold", fontSize=12,
            spaceBefore=6, spaceAfter=2)))
        story.append(Paragraph(desc_f, BODY))

    doc.build(story, onFirstPage=add_page_number, onLaterPages=add_page_number)
    print(f"Project documentation PDF created: {OUTPUT}")


build()

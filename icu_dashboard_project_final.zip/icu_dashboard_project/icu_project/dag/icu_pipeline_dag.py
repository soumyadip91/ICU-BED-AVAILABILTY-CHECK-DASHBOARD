from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.utils.dates import days_ago

# ── Project paths (update to your absolute path) ─────────────────────────────
PROJECT_DIR = "/home/user/icu_dashboard_project"
PYTHON_BIN  = "/usr/bin/python3"
SPARK_SUBMIT = "spark-submit"
# ─────────────────────────────────────────────────────────────────────────────

default_args = {
    "owner"           : "data_engineering_student",
    "depends_on_past" : False,
    "email_on_failure": False,
    "email_on_retry"  : False,
    "retries"         : 1,
    "retry_delay"     : timedelta(minutes=5),
    "start_date"      : days_ago(1),
}

with DAG(
    dag_id              = "icu_bed_availability_pipeline",
    default_args        = default_args,
    description         = "End-to-end ICU Bed Availability Data Pipeline",
    schedule_interval   = "0 1 * * *",    # daily at 01:00
    catchup             = False,
    max_active_runs     = 1,
    tags                = ["data_engineering", "icu", "capstone"],
) as dag:

    # ── Task 1: Generate / refresh the dataset ────────────────────────────────
    t1_generate_data = BashOperator(
        task_id     = "generate_dataset",
        bash_command= f"{PYTHON_BIN} {PROJECT_DIR}/scripts/generate_dataset.py",
        doc_md      = "Generates/refreshes the ICU CSV dataset from source.",
    )

    # ── Task 2: Start Kafka Producer ──────────────────────────────────────────
    t2_kafka_produce = BashOperator(
        task_id     = "kafka_produce",
        bash_command= f"{PYTHON_BIN} {PROJECT_DIR}/scripts/kafka_producer.py",
        doc_md      = "Reads CSV and publishes messages to Kafka topic 'icu_beds'.",
    )

    # ── Task 3: Kafka Consumer → HDFS ─────────────────────────────────────────
    t3_kafka_consume = BashOperator(
        task_id     = "kafka_consume_to_hdfs",
        bash_command= f"{PYTHON_BIN} {PROJECT_DIR}/scripts/kafka_consumer.py",
        doc_md      = "Consumes Kafka messages and writes JSON files to HDFS.",
    )

    # ── Task 4: Spark ETL Transformation ─────────────────────────────────────
    t4_spark_transform = BashOperator(
        task_id     = "spark_etl_transform",
        bash_command= (
            f"{SPARK_SUBMIT} --master local[*] "
            f"--driver-memory 2g "
            f"{PROJECT_DIR}/scripts/spark_transform.py"
        ),
        doc_md      = "PySpark job: clean, transform, compute occupancy metrics, write Parquet.",
    )

    # ── Task 5: Load Processed Data to SQLite ────────────────────────────────
    t5_load_sql = BashOperator(
        task_id     = "load_to_sqlite",
        bash_command= f"{PYTHON_BIN} {PROJECT_DIR}/scripts/load_to_sql.py",
        doc_md      = "Loads processed data into SQLite and creates analytical views.",
    )

    # ── Task 6: Upload to AWS S3 ──────────────────────────────────────────────
    t6_s3_upload = BashOperator(
        task_id     = "upload_to_s3",
        bash_command= f"{PYTHON_BIN} {PROJECT_DIR}/scripts/s3_upload.py",
        doc_md      = "Uploads processed DB and dataset files to AWS S3 bucket.",
    )

    # ── Task Dependencies (Pipeline Order) ───────────────────────────────────
    t1_generate_data >> t2_kafka_produce >> t3_kafka_consume >> \
    t4_spark_transform >> t5_load_sql >> t6_s3_upload

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak
)
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER

OUTPUT = "/home/claude/icu_project/docs/SRS_ICU_Bed_Availability_Dashboard.pdf"

def add_page_number(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 9)
    canvas.drawRightString(A4[0] - 1.5 * cm, 1.2 * cm, f"{doc.page}")
    canvas.restoreState()

def build():
    doc = SimpleDocTemplate(
        OUTPUT, pagesize=A4,
        rightMargin=2*cm, leftMargin=2*cm,
        topMargin=2*cm, bottomMargin=2*cm
    )

    styles = getSampleStyleSheet()
    heading1 = ParagraphStyle("H1", parent=styles["Heading1"],
                               fontName="Helvetica-Bold", fontSize=15,
                               spaceAfter=8, textColor=colors.HexColor("#1a3c6e"))
    heading2 = ParagraphStyle("H2", parent=styles["Heading2"],
                               fontName="Helvetica-Bold", fontSize=14,
                               spaceAfter=6, textColor=colors.HexColor("#1a3c6e"))
    body = ParagraphStyle("Body", parent=styles["Normal"],
                           fontName="Helvetica", fontSize=12,
                           leading=18, alignment=TA_JUSTIFY, spaceAfter=6)
    bold_body = ParagraphStyle("BoldBody", parent=body, fontName="Helvetica-Bold")
    center = ParagraphStyle("Center", parent=styles["Normal"],
                             fontName="Helvetica", fontSize=12, alignment=TA_CENTER)
    title_style = ParagraphStyle("Title", parent=styles["Title"],
                                  fontName="Helvetica-Bold", fontSize=18,
                                  textColor=colors.HexColor("#1a3c6e"),
                                  alignment=TA_CENTER, spaceAfter=6)

    story = []

    # Title page
    story.append(Spacer(1, 2*cm))
    story.append(Paragraph("Software Requirements Specification (SRS)", title_style))
    story.append(Spacer(1, 0.5*cm))
    story.append(Paragraph("ICU Bed Availability Dashboard", ParagraphStyle(
        "sub", parent=title_style, fontSize=16, textColor=colors.HexColor("#2e6da4"))))
    story.append(Spacer(1, 0.5*cm))
    story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#1a3c6e")))
    story.append(Spacer(1, 1*cm))

    meta_data = [
        ["Subject", "Data Engineering Capstone Project"],
        ["Project Title", "ICU Bed Availability Dashboard"],
        ["Tools Used", "Python, SQL, Hadoop (HDFS), Apache Spark, Apache Kafka,"],
        ["", "Apache Airflow, AWS S3"],
        ["Document Version", "1.0"],
        ["Submission Deadline", "April 21, 2026"],
    ]
    t = Table(meta_data, colWidths=[5*cm, 11*cm])
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 12),
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#dce8f5")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(t)
    story.append(PageBreak())

    # 1. Introduction
    story.append(Paragraph("1. Introduction", heading1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.3*cm))

    story.append(Paragraph("1.1 Purpose", heading2))
    story.append(Paragraph(
        "This Software Requirements Specification (SRS) document describes the complete design, "
        "architecture, and functional requirements of the ICU Bed Availability Dashboard, a Data "
        "Engineering Capstone Project. The purpose of this system is to collect, process, transform, "
        "store, and visualize ICU bed availability data from hospitals using a modern end-to-end data "
        "engineering pipeline. The dashboard enables healthcare administrators and analysts to monitor "
        "real-time and historical ICU occupancy trends, supporting faster and more informed decisions "
        "during critical health situations.", body))

    story.append(Paragraph("1.2 Scope", heading2))
    story.append(Paragraph(
        "The project covers the entire data lifecycle from ingestion to visualization. A publicly "
        "available ICU/hospital dataset is used as the base source. The pipeline simulates streaming "
        "ingestion via Apache Kafka, batch processing via Apache Spark on Hadoop (HDFS), orchestration "
        "via Apache Airflow, cloud storage on AWS S3, relational querying via SQL (SQLite/PostgreSQL), "
        "and a final interactive dashboard built in Python (Dash/Plotly). The system is designed to be "
        "modular, reproducible, and production-aligned.", body))

    story.append(Paragraph("1.3 Definitions and Acronyms", heading2))
    defs = [
        ["Term", "Definition"],
        ["ICU", "Intensive Care Unit — critical care hospital beds"],
        ["HDFS", "Hadoop Distributed File System — distributed storage layer"],
        ["Kafka", "Apache Kafka — distributed event streaming platform"],
        ["Spark", "Apache Spark — in-memory distributed data processing engine"],
        ["Airflow", "Apache Airflow — workflow orchestration and scheduling tool"],
        ["S3", "Amazon Simple Storage Service — object storage on AWS cloud"],
        ["ETL", "Extract, Transform, Load — data pipeline pattern"],
        ["DAG", "Directed Acyclic Graph — Airflow workflow definition"],
        ["SRS", "Software Requirements Specification"],
    ]
    dt = Table(defs, colWidths=[4*cm, 12*cm])
    dt.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3c6e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 11),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f0f6fc")]),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(dt)
    story.append(PageBreak())

    # 2. Overall Description
    story.append(Paragraph("2. Overall System Description", heading1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.3*cm))

    story.append(Paragraph("2.1 System Overview", heading2))
    story.append(Paragraph(
        "The ICU Bed Availability Dashboard is a batch and near-real-time data pipeline that "
        "ingests hospital ICU records, processes them through multiple transformation layers, "
        "stores them in both distributed and cloud storage, and renders an interactive analytical "
        "dashboard. The system follows the Lambda Architecture pattern — supporting both speed "
        "layer (Kafka streaming) and batch layer (Spark + Hadoop) processing.", body))

    story.append(Paragraph("2.2 System Architecture", heading2))
    story.append(Paragraph(
        "The pipeline is structured into five logical layers as described below:", body))

    arch = [
        ["Layer", "Component", "Role"],
        ["Ingestion", "Apache Kafka + Python Producer", "Simulate live ICU data streaming"],
        ["Storage (Raw)", "HDFS + AWS S3", "Store raw CSV/JSON event files"],
        ["Processing", "Apache Spark (PySpark)", "Clean, transform, aggregate ICU data"],
        ["Orchestration", "Apache Airflow (DAG)", "Schedule and monitor pipeline tasks"],
        ["Serving", "SQL + Python Dash", "Query data and render the dashboard"],
    ]
    at = Table(arch, colWidths=[3.5*cm, 5.5*cm, 7*cm])
    at.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3c6e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 11),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f0f6fc")]),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(at)
    story.append(Spacer(1, 0.4*cm))

    story.append(Paragraph("2.3 Dataset Description", heading2))
    story.append(Paragraph(
        "The project uses a publicly available hospital/ICU dataset (sourced from Kaggle or "
        "synthesized to match real-world patterns). The dataset includes fields such as hospital "
        "name, region/state, total ICU beds, occupied beds, available beds, date of record, "
        "and patient severity levels. A Python script is used to simulate streaming events "
        "by replaying this dataset row by row through a Kafka topic.", body))

    story.append(PageBreak())

    # 3. Functional Requirements
    story.append(Paragraph("3. Functional Requirements", heading1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.3*cm))

    reqs = [
        ["FR-01", "Data Ingestion", "The system shall read ICU records from a CSV dataset and produce them as messages to a Kafka topic named 'icu_beds'."],
        ["FR-02", "Kafka Consumer", "A Kafka consumer shall read messages from the topic and write them to HDFS as JSON files."],
        ["FR-03", "HDFS Storage", "Raw data shall be stored in HDFS under /icu/raw/ directory partitioned by date."],
        ["FR-04", "AWS S3 Backup", "Processed data shall be uploaded to an AWS S3 bucket for cloud archival and access."],
        ["FR-05", "Spark Processing", "PySpark shall read from HDFS, clean null values, compute occupancy rate, and write the transformed output back to HDFS at /icu/processed/."],
        ["FR-06", "SQL Querying", "Transformed data shall be loaded into a SQL database (SQLite) for structured querying and aggregation."],
        ["FR-07", "Airflow DAG", "An Airflow DAG shall orchestrate all pipeline steps: ingest → process → upload → load SQL, running on a daily schedule."],
        ["FR-08", "Dashboard", "A Python Dash dashboard shall display: total ICU beds by region, occupancy rate trend over time, hospital-wise availability table, and an alert for hospitals below 20% availability."],
    ]
    req_table = Table(
        [["ID", "Module", "Requirement"]] + reqs,
        colWidths=[1.5*cm, 4*cm, 10.5*cm]
    )
    req_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3c6e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f0f6fc")]),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(req_table)
    story.append(PageBreak())

    # 4. Non-Functional Requirements
    story.append(Paragraph("4. Non-Functional Requirements", heading1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.3*cm))

    nfrs = [
        ("Scalability", "The Spark processing layer must be able to handle datasets up to 10 million rows by scaling executor memory and partitions."),
        ("Fault Tolerance", "Kafka consumer offsets shall be committed after successful writes to HDFS, ensuring no data loss on failure."),
        ("Modularity", "Each pipeline component (producer, consumer, Spark job, DAG, dashboard) must be independently runnable and testable."),
        ("Reproducibility", "The pipeline shall produce identical results when run on the same input dataset, supporting auditability."),
        ("Usability", "The dashboard shall be accessible via a web browser on localhost without additional authentication."),
        ("Performance", "The Spark transformation job shall complete processing of 1 million records within 5 minutes on a single-node local setup."),
    ]
    for title_nfr, desc in nfrs:
        story.append(Paragraph(f"4.x {title_nfr}", ParagraphStyle(
            "nfr", parent=body, fontName="Helvetica-Bold")))
        story.append(Paragraph(desc, body))

    story.append(PageBreak())

    # 5. Tech Stack
    story.append(Paragraph("5. Technology Stack", heading1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.3*cm))

    stack = [
        ["Technology", "Version", "Purpose"],
        ["Python", "3.10+", "Core scripting, data generation, dashboard"],
        ["Apache Kafka", "3.x", "Event streaming / message broker"],
        ["Apache Hadoop (HDFS)", "3.x", "Distributed raw and processed data storage"],
        ["Apache Spark (PySpark)", "3.x", "Distributed data transformation and aggregation"],
        ["Apache Airflow", "2.x", "Pipeline orchestration and scheduling"],
        ["AWS S3", "—", "Cloud object storage for processed data"],
        ["SQL (SQLite)", "3.x", "Relational data storage and querying"],
        ["Pandas", "2.x", "Data manipulation in Python scripts"],
        ["Dash / Plotly", "2.x", "Interactive web-based dashboard"],
    ]
    st = Table(stack, colWidths=[4.5*cm, 3*cm, 8.5*cm])
    st.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3c6e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 11),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f0f6fc")]),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(st)
    story.append(Spacer(1, 0.5*cm))

    # 6. Data Flow
    story.append(Paragraph("6. Data Flow Diagram (Textual)", heading1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "The data flows through the system in the following sequential stages:", body))

    flow_steps = [
        ("Step 1 — Data Source", "A public ICU dataset (CSV) is read by the Python Kafka Producer script."),
        ("Step 2 — Kafka Streaming", "Each row is published as a JSON message to the Kafka topic 'icu_beds'. The Kafka Consumer reads these messages."),
        ("Step 3 — HDFS Raw Storage", "The consumer writes raw JSON files to HDFS under /icu/raw/YYYY-MM-DD/."),
        ("Step 4 — Spark Transformation", "PySpark reads the raw HDFS data, drops nulls, computes occupancy_rate = occupied / total * 100, and writes parquet files to /icu/processed/."),
        ("Step 5 — AWS S3 Upload", "The processed parquet files are uploaded to an S3 bucket using boto3."),
        ("Step 6 — SQL Loading", "Processed data is loaded into SQLite via pandas and SQL queries are used to build aggregated summary tables."),
        ("Step 7 — Airflow Orchestration", "An Airflow DAG ties steps 1–6 into a scheduled pipeline with dependency management."),
        ("Step 8 — Dashboard", "The Dash app reads from SQLite and renders charts: occupancy bar chart by region, trend line, availability heatmap, and alert table."),
    ]
    for step_title, step_desc in flow_steps:
        story.append(Paragraph(step_title, ParagraphStyle("st", parent=body, fontName="Helvetica-Bold")))
        story.append(Paragraph(step_desc, body))

    story.append(PageBreak())

    # 7. Project Structure
    story.append(Paragraph("7. Project Directory Structure", heading1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.3*cm))

    structure = """icu_dashboard_project/
├── data/
│   ├── icu_raw_dataset.csv          # Source dataset
│   └── icu_processed.db             # SQLite database
├── scripts/
│   ├── kafka_producer.py            # Kafka producer (reads CSV, sends to topic)
│   ├── kafka_consumer.py            # Kafka consumer (reads topic, writes to HDFS)
│   ├── spark_transform.py           # PySpark ETL job
│   ├── s3_upload.py                 # Upload processed data to AWS S3
│   └── load_to_sql.py               # Load processed data into SQLite
├── sql/
│   └── queries.sql                  # SQL aggregation and view definitions
├── dag/
│   └── icu_pipeline_dag.py          # Airflow DAG definition
├── dashboard/
│   └── app.py                       # Dash dashboard application
├── docs/
│   └── SRS_ICU_Bed_Dashboard.pdf    # This document
└── README.md                        # Setup and run instructions"""

    story.append(Paragraph(structure.replace("\n", "<br/>").replace(" ", "&nbsp;"),
                            ParagraphStyle("code", parent=styles["Code"],
                                           fontName="Courier", fontSize=9,
                                           leading=14, backColor=colors.HexColor("#f4f4f4"),
                                           borderPadding=8)))
    story.append(Spacer(1, 0.5*cm))

    # 8. Evaluation Criteria
    story.append(Paragraph("8. Evaluation and Test Plan", heading1))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#2e6da4")))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "The project will be evaluated based on correctness of pipeline execution, quality of "
        "documentation, originality of code, dashboard functionality, and performance on the "
        "20-mark post-submission test scheduled for April 23, 2026. Each module will be "
        "individually tested as described below:", body))

    tests = [
        ["Module", "Test Description", "Expected Result"],
        ["Kafka Producer", "Run producer on 100 sample rows", "100 messages in icu_beds topic"],
        ["Kafka Consumer", "Consume all messages", "JSON files written to HDFS /icu/raw/"],
        ["Spark Job", "Run spark_transform.py locally", "Parquet files in /icu/processed/ with occupancy_rate column"],
        ["S3 Upload", "Run s3_upload.py with mock credentials", "Files visible in S3 bucket"],
        ["SQL Load", "Run load_to_sql.py", "SQLite db populated with processed rows"],
        ["Airflow DAG", "Trigger DAG manually", "All tasks green in Airflow UI"],
        ["Dashboard", "Open browser at localhost:8050", "Charts render with correct data"],
    ]
    tt = Table(tests, colWidths=[3.5*cm, 6*cm, 6.5*cm])
    tt.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3c6e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f0f6fc")]),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(tt)

    doc.build(story, onFirstPage=add_page_number, onLaterPages=add_page_number)
    print(f"SRS PDF created: {OUTPUT}")

build()

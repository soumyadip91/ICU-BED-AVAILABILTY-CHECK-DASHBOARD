
    SUM(total_icu_beds)               AS national_total_beds,
    SUM(occupied_beds)                AS national_occupied,
    SUM(available_beds)               AS national_available,
    ROUND(AVG(occupancy_rate), 2)     AS national_avg_occupancy,
    COUNT(DISTINCT hospital_name)     AS total_hospitals
FROM icu_records
WHERE record_date = (SELECT MAX(record_date) FROM icu_records);


SELECT
    region,
    SUM(total_icu_beds)               AS total_beds,
    SUM(occupied_beds)                AS occupied,
    SUM(available_beds)               AS available,
    ROUND(AVG(occupancy_rate), 2)     AS avg_occupancy_pct,
    COUNT(DISTINCT hospital_name)     AS hospitals
FROM icu_records
WHERE record_date = (SELECT MAX(record_date) FROM icu_records)
GROUP BY region
ORDER BY avg_occupancy_pct DESC;


SELECT
    r.hospital_name,
    r.city,
    r.region,
    r.ward_type,
    r.total_icu_beds,
    r.occupied_beds,
    r.available_beds,
    r.occupancy_rate,
    ROUND(100 - r.occupancy_rate, 2)  AS availability_pct,
    CASE
        WHEN (100 - r.occupancy_rate) < 10 THEN '🔴 CRITICAL'
        WHEN (100 - r.occupancy_rate) < 20 THEN '🟠 HIGH'
        WHEN (100 - r.occupancy_rate) < 35 THEN '🟡 WARNING'
        ELSE '🟢 NORMAL'
    END                               AS status,
    r.record_date
FROM icu_records r
INNER JOIN (
    SELECT hospital_name, MAX(record_date) AS max_date
    FROM icu_records
    GROUP BY hospital_name
) latest ON r.hospital_name = latest.hospital_name
         AND r.record_date  = latest.max_date
ORDER BY r.occupancy_rate DESC;


SELECT
    SUBSTR(record_date, 1, 7)         AS month,
    ROUND(AVG(occupancy_rate), 2)     AS avg_occupancy_rate,
    SUM(total_icu_beds)               AS total_beds,
    SUM(available_beds)               AS total_available
FROM icu_records
GROUP BY SUBSTR(record_date, 1, 7)
ORDER BY month;


SELECT
    hospital_name,
    city,
    region,
    total_icu_beds,
    available_beds,
    occupancy_rate
FROM icu_records
WHERE record_date = (SELECT MAX(record_date) FROM icu_records)
ORDER BY occupancy_rate DESC
LIMIT 10;


SELECT
    hospital_name,
    city,
    region,
    available_beds,
    total_icu_beds,
    ROUND(100 - occupancy_rate, 2)    AS availability_pct,
    record_date
FROM icu_records
WHERE (100 - occupancy_rate) < 20
  AND record_date = (SELECT MAX(record_date) FROM icu_records)
ORDER BY availability_pct ASC;


SELECT
    ward_type,
    SUM(total_icu_beds)               AS total_beds,
    SUM(available_beds)               AS available_beds,
    ROUND(AVG(occupancy_rate), 2)     AS avg_occupancy
FROM icu_records
WHERE record_date = (SELECT MAX(record_date) FROM icu_records)
GROUP BY ward_type
ORDER BY avg_occupancy DESC;

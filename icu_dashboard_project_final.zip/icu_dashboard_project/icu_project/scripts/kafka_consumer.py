import json
import os
import subprocess
import tempfile
from datetime import datetime
from kafka import KafkaConsumer

KAFKA_BROKER  = "localhost:9092"
TOPIC_NAME    = "icu_beds"
GROUP_ID      = "icu_consumer_group"
HDFS_BASE     = "/icu/raw"
BATCH_SIZE    = 100        # messages before flushing to HDFS
TIMEOUT_MS    = 10_000     # stop polling if no message for 10 s


def write_to_hdfs(records: list, date_str: str, batch_num: int):
    """Write a list of JSON records to HDFS as a single JSON-lines file."""
    hdfs_dir  = f"{HDFS_BASE}/{date_str}"
    hdfs_path = f"{hdfs_dir}/batch_{batch_num:05d}.json"

    # Ensure HDFS directory exists
    subprocess.run(
        ["hadoop", "fs", "-mkdir", "-p", hdfs_dir],
        check=True, capture_output=True
    )

    # Write to a local temp file, then put to HDFS
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as tmp:
        for rec in records:
            tmp.write(json.dumps(rec) + "\n")
        tmp_path = tmp.name

    subprocess.run(
        ["hadoop", "fs", "-put", tmp_path, hdfs_path],
        check=True, capture_output=True
    )
    os.remove(tmp_path)
    print(f"[Consumer] Written {len(records)} records to HDFS: {hdfs_path}")


def consume_messages():
    consumer = KafkaConsumer(
        TOPIC_NAME,
        bootstrap_servers=[KAFKA_BROKER],
        group_id=GROUP_ID,
        auto_offset_reset="earliest",
        enable_auto_commit=False,   # manual commit after HDFS write
        value_deserializer=lambda m: json.loads(m.decode("utf-8")),
        consumer_timeout_ms=TIMEOUT_MS,
    )

    print(f"[Consumer] Listening on topic '{TOPIC_NAME}'...")

    buffer      = []
    batch_count = 0
    total_read  = 0
    date_str    = datetime.now().strftime("%Y-%m-%d")

    for message in consumer:
        buffer.append(message.value)
        total_read += 1

        if len(buffer) >= BATCH_SIZE:
            write_to_hdfs(buffer, date_str, batch_count)
            consumer.commit()
            batch_count += 1
            buffer = []

    # Flush remaining messages
    if buffer:
        write_to_hdfs(buffer, date_str, batch_count)
        consumer.commit()

    consumer.close()
    print(f"[Consumer] Finished. Total messages consumed: {total_read}")


if __name__ == "__main__":
    consume_messages()

import json
import time
import pandas as pd
from kafka import KafkaProducer

KAFKA_BROKER = "localhost:9092"
TOPIC_NAME   = "icu_beds"
DATASET_PATH = "data/icu_raw_dataset.csv"
DELAY_SEC    = 0.05   # 50 ms between messages; set to 0 for bulk load

def create_producer():
    producer = KafkaProducer(
        bootstrap_servers=[KAFKA_BROKER],
        value_serializer=lambda v: json.dumps(v).encode("utf-8"),
        acks="all",               # wait for full acknowledgement
        retries=3,
    )
    return producer


def produce_messages():
    df = pd.read_csv(DATASET_PATH)
    producer = create_producer()

    print(f"[Producer] Loaded {len(df)} records from {DATASET_PATH}")
    print(f"[Producer] Sending to Kafka topic: '{TOPIC_NAME}' on {KAFKA_BROKER}")

    sent = 0
    for _, row in df.iterrows():
        message = row.to_dict()
        producer.send(TOPIC_NAME, value=message)
        sent += 1
        if sent % 500 == 0:
            print(f"[Producer] Sent {sent}/{len(df)} messages...")
        time.sleep(DELAY_SEC)

    producer.flush()
    producer.close()
    print(f"[Producer] Done. Total messages sent: {sent}")


if __name__ == "__main__":
    produce_messages()

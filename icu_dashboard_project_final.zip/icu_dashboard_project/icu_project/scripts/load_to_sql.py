import sqlite3
import pandas as pd
import os

DATASET_PATH = "data/icu_raw_dataset.csv"
DB_PATH      = "data/icu_processed.db"


def create_connection(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")  # better concurrency
    return conn


def load_main_table(conn: sqlite3.Connection, df: pd.DataFrame):
    """Load the full ICU dataset into the icu_records table."""
    df.to_sql("icu_records", conn, if_exists="replace", index=False)
    count = pd.read_sql("SELECT COUNT(*) AS cnt FROM icu_records", conn)["cnt"][0]
    print(f"[SQL] Loaded {count} rows into 'icu_records'")


def create_views(conn: sqlite3.Connection):
    """Create analytical SQL views for dashboard consumption."""
    cursor = conn.cursor()

    # Drop existing views if they exist
    cursor.executescript("""
        DROP VIEW IF EXISTS regional_summary;
        DROP VIEW IF EXISTS hospital_summary;
        DROP VIEW IF EXISTS alert_hospitals;
        DROP VIEW IF EXISTS monthly_trend;
    """)

    # View 1: Regional daily summary
    cursor.execute("""
        CREATE VIEW regional_summary AS
        SELECT
            region,
            record_date,
            SUM(total_icu_beds)   AS total_beds,
            SUM(occupied_beds)    AS total_occupied,
            SUM(available_beds)   AS total_available,
            ROUND(AVG(occupancy_rate), 2) AS avg_occupancy_rate,
            COUNT(DISTINCT hospital_name) AS hospital_count
        FROM icu_records
        GROUP BY region, record_date
        ORDER BY region, record_date;
    """)

    # View 2: Latest stats per hospital (most recent date)
    cursor.execute("""
        CREATE VIEW hospital_summary AS
        SELECT
            r.hospital_name,
            r.city,
            r.region,
            r.total_icu_beds,
            r.occupied_beds,
            r.available_beds,
            r.occupancy_rate,
            ROUND(100 - r.occupancy_rate, 2) AS availability_pct,
            r.record_date
        FROM icu_records r
        INNER JOIN (
            SELECT hospital_name, MAX(record_date) AS max_date
            FROM icu_records
            GROUP BY hospital_name
        ) latest ON r.hospital_name = latest.hospital_name
                 AND r.record_date  = latest.max_date;
    """)

    # View 3: Alert hospitals (availability < 20%)
    cursor.execute("""
        CREATE VIEW alert_hospitals AS
        SELECT
            hospital_name,
            city,
            region,
            total_icu_beds,
            available_beds,
            occupancy_rate,
            ROUND(100 - occupancy_rate, 2) AS availability_pct,
            CASE
                WHEN (100 - occupancy_rate) < 10 THEN 'CRITICAL'
                WHEN (100 - occupancy_rate) < 20 THEN 'HIGH'
                ELSE 'WARNING'
            END AS alert_level,
            record_date
        FROM icu_records
        WHERE (100 - occupancy_rate) < 20
        ORDER BY occupancy_rate DESC;
    """)

    # View 4: Monthly national trend
    cursor.execute("""
        CREATE VIEW monthly_trend AS
        SELECT
            SUBSTR(record_date, 1, 7)   AS month,
            SUM(total_icu_beds)         AS national_total_beds,
            SUM(occupied_beds)          AS national_occupied,
            SUM(available_beds)         AS national_available,
            ROUND(AVG(occupancy_rate), 2) AS national_avg_occupancy
        FROM icu_records
        GROUP BY SUBSTR(record_date, 1, 7)
        ORDER BY month;
    """)

    conn.commit()
    print("[SQL] Views created: regional_summary, hospital_summary, alert_hospitals, monthly_trend")


def run_sample_queries(conn: sqlite3.Connection):
    """Run and print a few sample queries to verify the data."""
    print("\n[SQL] === Sample Query Results ===")

    q1 = pd.read_sql("""
        SELECT region, ROUND(AVG(avg_occupancy_rate),2) AS overall_avg
        FROM regional_summary
        GROUP BY region
        ORDER BY overall_avg DESC
    """, conn)
    print("\nRegion-wise Average ICU Occupancy:")
    print(q1.to_string(index=False))

    q2 = pd.read_sql("""
        SELECT hospital_name, city, occupancy_rate, availability_pct
        FROM hospital_summary
        ORDER BY occupancy_rate DESC
        LIMIT 5
    """, conn)
    print("\nTop 5 Most Occupied Hospitals (Latest Data):")
    print(q2.to_string(index=False))

    q3 = pd.read_sql("""
        SELECT month, national_avg_occupancy
        FROM monthly_trend
        LIMIT 6
    """, conn)
    print("\nMonthly National Trend (first 6 months):")
    print(q3.to_string(index=False))


def main():
    print(f"[SQL] Loading data from: {DATASET_PATH}")
    df = pd.read_csv(DATASET_PATH)
    print(f"[SQL] Read {len(df)} rows.")

    os.makedirs("data", exist_ok=True)
    conn = create_connection(DB_PATH)

    load_main_table(conn, df)
    create_views(conn)
    run_sample_queries(conn)

    conn.close()
    print(f"\n[SQL] Database saved to: {DB_PATH}")


if __name__ == "__main__":
    main()

import pandas as pd
import numpy as np
import random
import os
from datetime import datetime, timedelta

random.seed(42)
np.random.seed(42)

HOSPITALS = [
    ("AIIMS Delhi",               "Delhi",      "North"),
    ("Apollo Hospitals",          "Chennai",    "South"),
    ("Fortis Hospital",           "Gurugram",   "North"),
    ("Narayana Health",           "Bengaluru",  "South"),
    ("Kokilaben Hospital",        "Mumbai",     "West"),
    ("Medanta Hospital",          "Gurugram",   "North"),
    ("Manipal Hospital",          "Bengaluru",  "South"),
    ("Christian Medical College", "Vellore",    "South"),
    ("Tata Memorial Hospital",    "Mumbai",     "West"),
    ("PGI Chandigarh",            "Chandigarh", "North"),
    ("Sir Ganga Ram Hospital",    "Delhi",      "North"),
    ("Ruby Hall Clinic",          "Pune",       "West"),
    ("Amrita Hospital",           "Kochi",      "South"),
    ("Lilavati Hospital",         "Mumbai",     "West"),
    ("Care Hospitals",            "Bhubaneswar","East"),
]

WARD_TYPES = ["General ICU", "Cardiac ICU", "Surgical ICU"]

records = []
start_date = datetime(2024, 1, 1)

for hospital, city, region in HOSPITALS:
    total_icu = random.randint(20, 100)
    for day_offset in range(365):
        date = start_date + timedelta(days=day_offset)
        month = date.month
        base_rate = 0.55 + (0.15 if month in [11, 12, 1, 2] else 0.05)
        base_rate += random.uniform(-0.1, 0.1)
        base_rate = max(0.1, min(0.98, base_rate))

        occupied  = int(total_icu * base_rate)
        available = total_icu - occupied

        records.append({
            "hospital_name" : hospital,
            "city"          : city,
            "region"        : region,
            "ward_type"     : random.choice(WARD_TYPES),
            "total_icu_beds": total_icu,
            "occupied_beds" : occupied,
            "available_beds": available,
            "occupancy_rate": round(occupied / total_icu * 100, 2),
            "record_date"   : date.strftime("%Y-%m-%d"),
        })

df = pd.DataFrame(records)

# Create data folder automatically if it doesn't exist
os.makedirs("data", exist_ok=True)

df.to_csv("data/icu_raw_dataset.csv", index=False)
print(f"Done! Dataset saved to: data/icu_raw_dataset.csv")
print(f"Total rows: {len(df)}")
print(df.head(3).to_string())

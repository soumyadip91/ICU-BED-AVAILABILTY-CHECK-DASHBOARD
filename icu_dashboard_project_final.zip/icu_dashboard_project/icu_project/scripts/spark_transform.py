from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType, IntegerType

HDFS_RAW_PATH       = "hdfs://localhost:9000/icu/raw/*/*"
HDFS_PROCESSED_PATH = "hdfs://localhost:9000/icu/processed"

# For local testing without HDFS, use file paths:
# HDFS_RAW_PATH       = "data/icu_raw_dataset.csv"
# HDFS_PROCESSED_PATH = "data/icu_processed_spark"


def create_spark_session():
    spark = (
        SparkSession.builder
        .appName("ICU_Bed_Availability_ETL")
        .config("spark.sql.shuffle.partitions", "4")   # small dataset, reduce partitions
        .config("spark.executor.memory", "2g")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("WARN")
    return spark


def run_etl(spark: SparkSession):
    print("[Spark] Reading raw data from HDFS...")

    # Read JSON files (one JSON object per line)
    df_raw = spark.read.option("multiline", "false").json(HDFS_RAW_PATH)

    print(f"[Spark] Raw record count: {df_raw.count()}")
    df_raw.printSchema()

    # ── 1. Drop rows with nulls in critical columns ──────────────────────────
    critical_cols = [
        "hospital_name", "record_date", "total_icu_beds",
        "occupied_beds", "available_beds"
    ]
    df_clean = df_raw.dropna(subset=critical_cols)

    # ── 2. Cast columns to correct types ─────────────────────────────────────
    df_typed = (
        df_clean
        .withColumn("total_icu_beds",      F.col("total_icu_beds").cast(IntegerType()))
        .withColumn("occupied_beds",       F.col("occupied_beds").cast(IntegerType()))
        .withColumn("available_beds",      F.col("available_beds").cast(IntegerType()))
        .withColumn("severity_critical",   F.col("severity_critical").cast(IntegerType()))
        .withColumn("severity_moderate",   F.col("severity_moderate").cast(IntegerType()))
    )

    # ── 3. Compute derived metrics ────────────────────────────────────────────
    df_enriched = (
        df_typed
        # Recalculate occupancy rate (overwrite raw value for accuracy)
        .withColumn(
            "occupancy_rate",
            F.round(
                F.col("occupied_beds").cast(DoubleType()) /
                F.col("total_icu_beds").cast(DoubleType()) * 100,
                2
            )
        )
        # Availability percentage
        .withColumn(
            "availability_pct",
            F.round(100 - F.col("occupancy_rate"), 2)
        )
        # Alert flag: hospitals below 20% availability are critical
        .withColumn(
            "low_availability_alert",
            F.when(F.col("availability_pct") < 20, "CRITICAL")
             .when(F.col("availability_pct") < 35, "WARNING")
             .otherwise("NORMAL")
        )
        # Parse date properly
        .withColumn("record_date", F.to_date(F.col("record_date"), "yyyy-MM-dd"))
        .withColumn("record_month", F.month(F.col("record_date")))
        .withColumn("record_year",  F.year(F.col("record_date")))
    )

    # ── 4. Deduplicate (hospital + date should be unique per entry) ───────────
    df_final = df_enriched.dropDuplicates(["hospital_name", "record_date", "ward_type"])

    print(f"[Spark] Processed record count: {df_final.count()}")

    # ── 5. Write output as Parquet to HDFS ────────────────────────────────────
    (
        df_final
        .write
        .mode("overwrite")
        .partitionBy("record_year", "record_month")
        .parquet(HDFS_PROCESSED_PATH)
    )
    print(f"[Spark] Processed data written to: {HDFS_PROCESSED_PATH}")

    # ── 6. Compute regional summary (saved as separate Parquet) ───────────────
    df_regional = (
        df_final.groupBy("region", "record_date")
        .agg(
            F.sum("total_icu_beds").alias("total_beds"),
            F.sum("occupied_beds").alias("total_occupied"),
            F.sum("available_beds").alias("total_available"),
            F.round(F.avg("occupancy_rate"), 2).alias("avg_occupancy_rate"),
        )
        .orderBy("region", "record_date")
    )

    (
        df_regional
        .write
        .mode("overwrite")
        .parquet(f"{HDFS_PROCESSED_PATH}_regional_summary")
    )
    print("[Spark] Regional summary written.")

    # Show a quick sample
    df_final.select(
        "hospital_name", "record_date", "occupancy_rate",
        "availability_pct", "low_availability_alert"
    ).show(10, truncate=False)

    spark.stop()


if __name__ == "__main__":
    spark = create_spark_session()
    run_etl(spark)

import os
import boto3
from botocore.exceptions import ClientError, NoCredentialsError

# ── Configuration ─────────────────────────────────────────────────────────────
S3_BUCKET_NAME   = "icu-bed-dashboard-data"
S3_PREFIX        = "processed/"           # folder inside bucket
LOCAL_DATA_PATH  = "data/"                # local folder to upload from
AWS_REGION       = "ap-south-1"          # Mumbai region
# ─────────────────────────────────────────────────────────────────────────────


def get_s3_client():
    """Create and return a boto3 S3 client."""
    client = boto3.client("s3", region_name=AWS_REGION)
    return client


def create_bucket_if_not_exists(s3_client, bucket_name: str, region: str):
    """Create the S3 bucket if it does not already exist."""
    try:
        s3_client.head_bucket(Bucket=bucket_name)
        print(f"[S3] Bucket '{bucket_name}' already exists.")
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code in ("404", "NoSuchBucket"):
            print(f"[S3] Creating bucket '{bucket_name}' in region '{region}'...")
            s3_client.create_bucket(
                Bucket=bucket_name,
                CreateBucketConfiguration={"LocationConstraint": region},
            )
            print("[S3] Bucket created successfully.")
        else:
            raise


def upload_file(s3_client, local_path: str, bucket: str, s3_key: str):
    """Upload a single file to S3."""
    try:
        s3_client.upload_file(local_path, bucket, s3_key)
        print(f"[S3] Uploaded: {local_path}  →  s3://{bucket}/{s3_key}")
    except FileNotFoundError:
        print(f"[S3] ERROR: File not found: {local_path}")
    except NoCredentialsError:
        print("[S3] ERROR: AWS credentials not found. Run 'aws configure'.")
        raise


def upload_directory(s3_client, local_dir: str, bucket: str, prefix: str):
    """Recursively upload all files in a local directory to S3."""
    total = 0
    for root, _, files in os.walk(local_dir):
        for filename in files:
            local_path = os.path.join(root, filename)
            # Build S3 key preserving subdirectory structure
            relative_path = os.path.relpath(local_path, local_dir)
            s3_key = os.path.join(prefix, relative_path).replace("\\", "/")
            upload_file(s3_client, local_path, bucket, s3_key)
            total += 1
    return total


def main():
    print("[S3] Starting upload to AWS S3...")
    try:
        s3 = get_s3_client()
        create_bucket_if_not_exists(s3, S3_BUCKET_NAME, AWS_REGION)

        # Upload only the processed CSV/Parquet, skip raw large files
        files_to_upload = [
            ("data/icu_raw_dataset.csv",  f"{S3_PREFIX}icu_raw_dataset.csv"),
            ("data/icu_processed.db",     f"{S3_PREFIX}icu_processed.db"),
        ]

        for local_file, s3_key in files_to_upload:
            if os.path.exists(local_file):
                upload_file(s3, local_file, S3_BUCKET_NAME, s3_key)
            else:
                print(f"[S3] Skipping (not found): {local_file}")

        print("[S3] Upload complete.")

    except NoCredentialsError:
        print("[S3] Configure AWS credentials first: aws configure")
    except Exception as e:
        print(f"[S3] Unexpected error: {e}")


if __name__ == "__main__":
    main()

# ICU Bed Availability Dashboard
### Data Engineering Capstone Project

---

## Project Overview
An end-to-end Data Engineering pipeline that ingests, processes, stores, and visualizes ICU bed availability data across hospitals. The system uses Apache Kafka for streaming ingestion, Hadoop (HDFS) for distributed storage, Apache Spark for transformation, Apache Airflow for orchestration, AWS S3 for cloud storage, SQL for querying, and a Dash/Plotly dashboard for visualization.

---

## Tech Stack
| Tool | Purpose |
|---|---|
| Python 3.10+ | Scripting, data generation, dashboard |
| Apache Kafka | Event streaming (data ingestion) |
| Apache Hadoop (HDFS) | Distributed file storage |
| Apache Spark (PySpark) | ETL transformation |
| Apache Airflow | Pipeline orchestration |
| AWS S3 | Cloud storage |
| SQLite (SQL) | Structured querying |
| Dash + Plotly | Interactive dashboard |

---

## Project Structure
```
icu_dashboard_project/
├── data/
│   ├── icu_raw_dataset.csv       # Source dataset (7300 records)
│   └── icu_processed.db          # SQLite database
├── scripts/
│   ├── generate_dataset.py       # Dataset generator
│   ├── kafka_producer.py         # Kafka producer
│   ├── kafka_consumer.py         # Kafka consumer → HDFS
│   ├── spark_transform.py        # PySpark ETL job
│   ├── s3_upload.py              # AWS S3 uploader
│   └── load_to_sql.py            # SQLite loader + views
├── sql/
│   └── queries.sql               # SQL queries
├── dag/
│   └── icu_pipeline_dag.py       # Airflow DAG
├── dashboard/
│   └── app.py                    # Dash dashboard
├── docs/
│   └── SRS_ICU_Bed_Availability_Dashboard.pdf
└── README.md
```

---

## Setup & Run

### 1. Install Python dependencies
```bash
pip install pandas numpy faker kafka-python pyspark boto3 dash plotly
```

### 2. Generate Dataset
```bash
python scripts/generate_dataset.py
```

### 3. Start Kafka (requires Kafka installed)
```bash
# Terminal 1 — Zookeeper
bin/zookeeper-server-start.sh config/zookeeper.properties

# Terminal 2 — Kafka Broker
bin/kafka-server-start.sh config/server.properties

# Create topic (first time only)
bin/kafka-topics.sh --create --topic icu_beds \
  --bootstrap-server localhost:9092 \
  --partitions 1 --replication-factor 1
```

### 4. Run Kafka Producer & Consumer
```bash
# Terminal 3
python scripts/kafka_producer.py

# Terminal 4
python scripts/kafka_consumer.py
```

### 5. Run Spark ETL
```bash
spark-submit --master local[*] scripts/spark_transform.py
```

### 6. Load to SQL
```bash
python scripts/load_to_sql.py
```

### 7. Upload to S3
```bash
# Configure AWS credentials first
aws configure
python scripts/s3_upload.py
```

### 8. Start Dashboard
```bash
python dashboard/app.py
# Open: http://localhost:8050
```

### 9. Airflow (optional)
```bash
cp dag/icu_pipeline_dag.py $AIRFLOW_HOME/dags/
airflow db init
airflow webserver -p 8080 &
airflow scheduler &
# Open: http://localhost:8080
```

---

## Dashboard Features
- National KPI cards (total beds, occupied, available, avg occupancy)
- Real-time alert banner for critical hospitals
- Region-wise occupancy bar chart
- Monthly national trend line chart
- Ward type breakdown donut chart
- Alert table (hospitals < 20% availability)
- Sortable, filterable hospital data table with CSV export
- Region filter dropdown

---

## Pipeline Architecture
```
CSV Dataset
    ↓
Python Kafka Producer  →  Kafka Topic (icu_beds)
                                ↓
                       Kafka Consumer → HDFS (/icu/raw/)
                                            ↓
                                    PySpark ETL → HDFS (/icu/processed/)
                                                       ↓
                                              AWS S3 (cloud backup)
                                                       ↓
                                             SQLite (icu_processed.db)
                                                       ↓
                                          Dash Dashboard (localhost:8050)
                                                       ↑
                                          Airflow DAG (orchestrates all)
```
